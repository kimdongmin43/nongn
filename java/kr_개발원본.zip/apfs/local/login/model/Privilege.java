package kr.apfs.local.login.model;
/**
 * 
 * @author h2y
 *
 */
public class Privilege {
	/**
	 * 
	 */
	private String name;

	/**
	 * @return the name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * @param value the name to set
	 */
	public final void setName(final String value) {
		this.name = value;
	}
}
